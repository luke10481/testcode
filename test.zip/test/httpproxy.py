from mitmproxy import http, ctx
import json
import urllib.parse
from mitmproxy.tools import main


class RequestModifier:
    def __init__(self):
        self.modified_requests = 0

    def request(self, flow: http.HTTPFlow) -> None:
        """
        处理所有传入的请求
        """
        # 只处理目标请求（根据路径判断）
        if "deepseek.com" in flow.request.path:
            print()
            self.modified_requests += 1
            ctx.log.info(f"修改请求 #{self.modified_requests}: {flow.request.url}")

            # 修改查询参数
            self.modify_query_params(flow)

            # 修改请求头
            self.modify_headers(flow)

            # 修改请求体
            self.modify_body(flow)

            # 打印修改后的请求信息
            self.log_modified_request(flow)

    def modify_query_params(self, flow: http.HTTPFlow) -> None:
        """
        修改查询参数
        """
        # 获取当前查询参数
        params = flow.request.query

        # 修改现有参数
        if "w" in params:
            params["w"] = "modified_hhh"

        if "pename" in params:
            params["pename"] = "modified_dingding"

        # 添加新参数
        params["timestamp"] = str(ctx.master.times.timestamp())
        params["modified_by"] = "mitmproxy_plugin"

        # 注意：不需要手动设置回，修改是原地进行的

    def modify_headers(self, flow: http.HTTPFlow) -> None:
        """
        修改请求头
        """
        headers = flow.request.headers

        # 修改 User-Agent
        headers[
            "user-agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 [MITM-Modified]"

        # 修改或添加自定义头
        headers["x-mitmproxy-modified"] = "true"
        headers["x-request-id"] = f"req-{self.modified_requests}"

        # 删除特定头（如果需要）
        # if "accept-encoding" in headers:
        #     del headers["accept-encoding"]

    def modify_body(self, flow: http.HTTPFlow) -> None:
        """
        修改请求体
        """
        # 检查是否有请求体
        if not flow.request.content:
            return

        # 根据 Content-Type 处理不同类型的请求体
        content_type = flow.request.headers.get("content-type", "").lower()

        if "application/json" in content_type:
            self.modify_json_body(flow)
        elif "application/x-www-form-urlencoded" in content_type:
            self.modify_form_body(flow)
        else:
            # 对于其他类型，尝试作为文本处理
            self.modify_text_body(flow)

    def modify_json_body(self, flow: http.HTTPFlow) -> None:
        """
        修改 JSON 格式的请求体
        """
        try:
            # 获取并解析 JSON 体
            body_text = flow.request.get_text()
            if body_text.strip():  # 确保不是空字符串
                json_data = json.loads(body_text)

                # 修改现有字段
                if "aa" in json_data:
                    json_data["aa"] = "modified_aaa"

                # 添加新字段
                json_data["mitmproxy_modified"] = True
                json_data["request_count"] = self.modified_requests
                json_data["timestamp"] = ctx.master.times.timestamp()

                # 设置回修改后的 JSON
                flow.request.set_text(json.dumps(json_data))
                ctx.log.info("已修改 JSON 请求体")

        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            ctx.log.warn(f"解析 JSON 请求体失败: {e}")

    def modify_form_body(self, flow: http.HTTPFlow) -> None:
        """
        修改表单格式的请求体
        """
        try:
            body_text = flow.request.get_text()
            if body_text.strip():
                # 解析表单数据
                form_data = urllib.parse.parse_qs(body_text)

                # 修改表单数据
                for key in form_data:
                    form_data[key] = [f"modified_{value}" for value in form_data[key]]

                # 添加新字段
                form_data["mitmproxy_modified"] = ["true"]

                # 重新编码并设置回
                new_body = urllib.parse.urlencode(form_data, doseq=True)
                flow.request.set_text(new_body)
                ctx.log.info("已修改表单请求体")

        except Exception as e:
            ctx.log.warn(f"修改表单请求体失败: {e}")

    def modify_text_body(self, flow: http.HTTPFlow) -> None:
        """
        修改纯文本请求体
        """
        try:
            original_body = flow.request.get_text()
            if original_body.strip():
                modified_body = f"[MITM-MODIFIED] {original_body}"
                flow.request.set_text(modified_body)
                ctx.log.info("已修改文本请求体")
        except UnicodeDecodeError as e:
            ctx.log.warn(f"修改文本请求体失败: {e}")

    def log_modified_request(self, flow: http.HTTPFlow) -> None:
        """
        记录修改后的请求详情
        """
        ctx.log.info("=== 修改后的请求 ===")
        ctx.log.info(f"URL: {flow.request.pretty_url}")
        ctx.log.info(f"方法: {flow.request.method}")
        ctx.log.info(f"查询参数: {dict(flow.request.query)}")
        ctx.log.info(f"请求头: {dict(flow.request.headers)}")

        if flow.request.content:
            try:
                body = flow.request.get_text()
                ctx.log.info(f"请求体: {body}")
            except:
                ctx.log.info("请求体: [二进制数据，无法显示]")

        ctx.log.info("=" * 50)


# 创建插件实例
addons = [RequestModifier()]

if __name__ == '__main__':
    main.mitmdump(['-s', __file__, '--listen-host', '0.0.0.0', '-p', '9090', '--set', 'block_global=false'])
