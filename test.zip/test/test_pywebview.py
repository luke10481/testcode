import webview
import json
import threading
import os
from pathlib import Path
import time

# 数据文件路径
DATA_FILE = "mitm_data.json"


# 简化的mitmproxy数据采集（实际使用时需要安装mitmproxy）
def collect_mitm_data():
    """模拟mitmproxy收集数据并保存到JSON文件"""
    import random

    while True:
        time.sleep(2)  # 模拟每2秒收集一次数据

        # 如果文件不存在，创建空列表
        if not os.path.exists(DATA_FILE):
            with open(DATA_FILE, 'w', encoding='utf-8') as f:
                json.dump([], f)

        # 读取现有数据
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            try:
                data = json.load(f)
            except:
                data = []

        # 添加新数据（模拟mitmproxy捕获）
        new_item = {
            "id": len(data) + 1,
            "url": f"https://api.example.com/v{random.randint(1, 3)}/data",
            "method": random.choice(["GET", "POST", "PUT"]),
            "request_body": {"user_id": random.randint(1000, 9999), "action": "query"},
            "timestamp": time.strftime("%H:%M:%S"),
            "status": random.choice([200, 404, 500])
        }

        data.append(new_item)

        # 保存数据（只保留最近50条）
        if len(data) > 50:
            data = data[-50:]

        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)


# HTML模板
html = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { border-collapse: collapse; width: 100%; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; position: sticky; top: 0; }
        tr:hover { background-color: #f5f5f5; }
        pre { margin: 0; font-size: 12px; max-height: 100px; overflow: auto; }
        .method-get { color: green; }
        .method-post { color: orange; }
        .method-put { color: blue; }
        .status-200 { color: green; }
        .status-404 { color: orange; }
        .status-500 { color: red; }
    </style>
</head>
<body>
    <h3>mitmproxy捕获的请求数据</h3>
    <div>更新时间: <span id="update-time">-</span></div>
    <table id="data-table">
        <thead>
            <tr>
                <th width="50">ID</th>
                <th width="150">时间</th>
                <th width="80">方法</th>
                <th>URL</th>
                <th width="80">状态</th>
                <th width="300">请求体</th>
            </tr>
        </thead>
        <tbody id="table-body"></tbody>
    </table>

    <script>
        function updateTable(data) {
            const tbody = document.getElementById('table-body');
            const updateTime = document.getElementById('update-time');

            // 更新时间
            updateTime.textContent = new Date().toLocaleTimeString();

            // 清空现有数据
            tbody.innerHTML = '';

            // 添加新数据（从最新到最旧显示）
            data.reverse().forEach(item => {
                const row = document.createElement('tr');

                // 格式化请求体
                const requestBody = item.request_body || {};
                const formattedBody = JSON.stringify(requestBody, null, 2);

                row.innerHTML = `
                    <td>${item.id}</td>
                    <td>${item.timestamp || '-'}</td>
                    <td class="method-${item.method?.toLowerCase() || 'get'}">
                        ${item.method || 'GET'}
                    </td>
                    <td style="word-break: break-all; max-width: 400px;">${item.url || '-'}</td>
                    <td class="status-${item.status || '200'}">
                        ${item.status || '-'}
                    </td>
                    <td>
                        <pre style="white-space: pre-wrap; max-height: 100px; overflow: auto;">
${formattedBody}
                        </pre>
                    </td>
                `;
                tbody.appendChild(row);
            });
        }

        // 从Python接收数据
        window.updateFromPython = (data) => {
            updateTable(data);
        };

        // 初始加载
        if (window.pywebview) {
            window.pywebview.api.load_initial_data().then(updateTable);
        }
    </script>
</body>
</html>
"""


def send_data_to_js(window):
    """定时读取JSON数据并发送到前端"""
    while True:
        time.sleep(1)  # 每秒更新一次

        try:
            if os.path.exists(DATA_FILE):
                with open(DATA_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)

                # 发送到JavaScript
                window.evaluate_js(f"updateFromPython({json.dumps(data)})")
        except Exception as e:
            print(f"发送数据出错: {e}")


def main():
    # 创建示例数据文件（如果不存在）
    if not os.path.exists(DATA_FILE):
        sample_data = [
            {
                "id": 1,
                "url": "https://api.example.com/v1/users",
                "method": "GET",
                "request_body": {"page": 1, "limit": 20},
                "timestamp": "14:30:25",
                "status": 200
            },
            {
                "id": 2,
                "url": "https://api.example.com/v1/login",
                "method": "POST",
                "request_body": {"username": "test", "password": "123456"},
                "timestamp": "14:31:10",
                "status": 200
            }
        ]
        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(sample_data, f, indent=2, ensure_ascii=False)

    # 创建窗口
    window = webview.create_window(
        'mitmproxy数据查看器',
        html=html,
        width=1200,
        height=700,
        min_size=(800, 500)
    )

    # 启动数据收集线程（模拟mitmproxy）
    threading.Thread(target=collect_mitm_data, daemon=True).start()

    # 启动数据发送线程
    threading.Thread(target=send_data_to_js, args=(window,), daemon=True).start()

    # 启动webview
    webview.start()


if __name__ == '__main__':
    main()