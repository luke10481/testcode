# 实际的mitmproxy处理器
from mitmproxy import http
import json
import time
from pathlib import Path
from mitmproxy.tools import main


class RequestRecorder:
    def __init__(self, data_file="mitm_data.json"):
        self.data_file = Path(data_file)
        self.data = []

        # 加载现有数据
        if self.data_file.exists():
            with open(self.data_file, 'r') as f:
                self.data = json.load(f)

    def request(self, flow: http.HTTPFlow):
        """捕获请求"""
        record = {
            "id": len(self.data) + 1,
            "url": flow.request.pretty_url,
            "method": flow.request.method,
            "request_body": flow.request.text or {},
            "timestamp": time.strftime("%H:%M:%S"),
            "status": flow.response.status_code if flow.response else None
        }

        self.data.append(record)

        # 只保留最近100条
        if len(self.data) > 100:
            self.data = self.data[-100:]

        # 保存到文件
        with open(self.data_file, 'w') as f:
            json.dump(self.data, f, indent=2)

addons = [RequestRecorder()]

if __name__ == '__main__':
    main.mitmdump(['-s', __file__, '--listen-host', '0.0.0.0', '-p', '9090', '--set', 'block_global=false'])