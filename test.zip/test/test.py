# -*- encoding: utf-8 -*-

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options

options = Options()
options.add_argument('--proxy-server=http://127.0.0.1:9090')
driverpath = Service(r'C:\Users\59483\PycharmProjects\PythonProject1\chromedriver-win64\chromedriver.exe')
driver = webdriver.Chrome(options=options, service=driverpath)
url = 'https://chat.deepseek.com'

driver.get(url)

web = driver.execute_script("return window.navigator.webdriver")
print(web)
driver.close()

# 输出
False