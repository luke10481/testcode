import requests
import pandas as pd
from flask import Flask, request

app = Flask(__name__)

@app.route("/partial_ssrf")
def partial_ssrf():
    user_info = request.args["user_id"]
    df = pd.DataFrame(user_info)
    resp = requests.get(df)
    for i in df.groupby('category'):
        resp = requests.get(i)
    for i in df.to_numpy():
        resp = requests.get(i)
    for i in df:
        resp = requests.get(i)
    for i in user_info:
        resp = requests.get(i)