package com.example;
import com.sun.org.apache.bcel.internal.classfile.JavaClass;
import com.sun.org.apache.bcel.internal.classfile.Utility;
import com.sun.org.apache.bcel.internal.Repository;

public class BCELencode {
    public static void main(String []args) throws Exception {
        JavaClass cls = Repository.lookupClass(com.example.BCELeval.class);
        String code = Utility.encode(cls.getBytes(), true);
        System.out.println(code);
    }
}
