package com.example.controller;

import com.example.dao.UserDao;
import com.example.model.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@RestController
public class UserController {
    @Autowired
    private UserDao userMapper;

    @GetMapping("/queryUserList")
    public List<User> queryUserList() {
        return userMapper.queryUserList();
    }

    @GetMapping("/queryUserByUsername{username}")
    public List<User> queryUserByUsername(String username) {
        return userMapper.queryUserByUsername(username);
    }

    @GetMapping("/addUser")
    public String addUser() {
        userMapper.addUser(new User(4, "zml", "45632"));
        return "增加用户完毕";
    }

    @GetMapping("/updateUser")
    public String updateUser() {
        userMapper.updateUser(new User(4, "zml", "678910"));
        return "修改用户完毕";
    }

    @GetMapping("/deleteUser")
    public String deleteUser() {
        userMapper.deleteUser(4);
        return "删除用户完毕";
    }

}