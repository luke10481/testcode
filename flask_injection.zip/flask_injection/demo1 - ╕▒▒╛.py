from flask import Flask, request, make_response, jsonify, session, render_template, url_for
from flask_cors import CORS
from werkzeug.utils import redirect, secure_filename

app = Flask(__name__)
app.secret_key = '123'
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config['SESSION_COOKIE_SECURE'] = True
app.config['MAX_CONTENT_LENGTH'] = 1 * 1024 * 1024

cors = CORS(app, resources={r"/api/*": {"origins": "*"}})

# 定义文件上传的路径
UPLOAD_FOLDER = '/path/to/upload'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route("/", methods=['GET', 'POST'])
def index():
    response = make_response('OK')
    session['top'] = 'a'
    response.set_cookie('key', 'value', httponly=True)
    return response

@app.route('/upload')
def upload():
   return render_template('upload.html')
@app.route('/uploader', methods = ['GET', 'POST'])

def uploader():
   if request.method == 'POST':
      f = request.files['file']
      f.save(secure_filename(f.filename))
      return 'file uploaded successfully'

if __name__ == '__main__':
    app.run()