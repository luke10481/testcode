import flask
import urllib
from flask import Flask, make_response
import os
app = flask.Flask(__name__)
app.config["SESSION_COOKIE_HTTPONLY"] = True

@app.route('/')
def index():
    resp = make_response("success")
    # 设置coolie,默认有效期是临时cookie，浏览器关闭就失效
    resp.set_cookie("itcast", "Python")
    return flask.render_template("127.0.0.1.html")

if __name__ == '__main__':
    app.run(debug=True)