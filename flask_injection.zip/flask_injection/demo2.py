import os
os.system('git --help')
os.system('git --help')
