from flask import Flask, request, jsonify, session

app = Flask(__name__)
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.secret_key = 'TPmi4aLWRbyVq8zu9v82dWYW1'


@app.route("/login", methods=["POST"])
def login():

    data = request.get_json()
    username = data.get("username")
    password = data.get("password")

    if not all([username, password]):
        return jsonify(re_code=400, msg="paramnotenough")

    if username == "admin" and password == 123:
        session["username"] = username
        return jsonify(msg="loginsuccess")
    else:
        return jsonify(msg="accountpasswordwrong")


@app.route("/session", methods=["GET"])
def check_session():
    username = session.get("username")
    if username is not None:
        return jsonify(username=username)
    else:
        return jsonify(msg="nologin")

@app.route("/logout", methods=["DELETE"])
def logout():
    session.pop("username")
    return jsonify(msg="logout")


app.run(host="0.0.0.0")