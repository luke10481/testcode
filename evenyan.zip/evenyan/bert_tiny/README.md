---
tasks:
- fill-mask
model-type:
- bert
domain:
- nlp
frameworks:
- pytorch
backbone:
- transformer
metrics:
- accuracy
license: Apache License 2.0
finetune-support: True
integrating: True
language:
- zh
tags:
- transformer
datasets:
  test:
  - modelscope/clue
  train:
  - modelscope/clue
---

# 该系列模型主要用于微调以适应下游NLP任务
