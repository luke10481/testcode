import pymysql
from flask import Flask, request

def query_user(input_id):
    # 模拟黑名单过滤（不全）
    blacklist = ["union", "select", " ", "--", "/*", "*/", "'", "="]
    input_lower = input_id.lower()
    for word in blacklist:
        if word in input_lower:
            raise ValueError("检测到非法输入!")

    # 直接拼接用户输入（存在注入风险）
    query = f"SELECT * FROM users WHERE id = {input_id}"
    return query

connection = pymysql.connect(
    host='159.75.114.202',
    user='windows',
    password='123456',
    database='python',
    port=3306
)
cursor = connection.cursor()  # 做事的人

q = request.json['data']
query = query_user(q)
cursor.execute(query)
cursor.close()
connection.close()