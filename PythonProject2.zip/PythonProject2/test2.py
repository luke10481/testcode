import json


def extract_code_from_sarif(sarif_path, source_root=''):
    """
    从SARIF文件中提取去重后的代码流数据

    :param sarif_path: SARIF文件路径
    :param source_root: 源代码根目录（用于路径拼接）
    :return: 去重后的代码流列表
    """
    with open(sarif_path, 'r', encoding='utf-8') as f:
        sarif_data = json.load(f)

    code_snippets = []
    file_cache = {}

    for run in sarif_data.get('runs', []):
        for result in run.get('results', []):
            for code_flow in result.get('codeFlows', []):
                for thread_flow in code_flow.get('threadFlows', []):
                    flow_path = []
                    seen_locations = set()  # 用于位置去重的集合

                    for location in thread_flow.get('locations', []):
                        phys_loc = location.get('location', {}).get('physicalLocation', {})
                        if not phys_loc:
                            continue

                        # 解析文件位置
                        artifact_loc = phys_loc.get('artifactLocation', {})
                        uri = artifact_loc.get('uri')
                        if not uri:
                            continue

                        file_path = source_root + uri

                        # 解析代码区域
                        region = phys_loc.get('region', {})
                        start_line = region.get('startLine')
                        end_line = region.get('endLine') or start_line

                        if not start_line:
                            continue

                        # 生成位置唯一标识
                        location_id = (file_path, start_line, end_line)
                        if location_id in seen_locations:
                            continue
                        seen_locations.add(location_id)

                        # 读取文件内容
                        if file_path not in file_cache:
                            try:
                                with open(file_path, 'r', encoding='utf-8') as f:
                                    file_cache[file_path] = f.readlines()
                            except Exception as e:
                                print(f"无法读取文件 {file_path}: {str(e)}")
                                continue

                        # 提取代码片段
                        start_idx = start_line - 1
                        end_idx = end_line
                        code_lines = file_cache[file_path][start_idx:end_idx]

                        flow_path.append({
                            'file': file_path,
                            'start_line': start_line,
                            'end_line': end_line,
                            'code': code_lines[0][:-1]
                        })

                    if flow_path:
                        # 全局去重：排除完全相同的代码流路径
                        path_signature = tuple((step['file'], step['start_line']) for step in flow_path)
                        if not any(existing_path == path_signature for existing_path in
                                   [tuple((s['file'], s['start_line']) for s in cs) for cs in code_snippets]):
                            code_snippets.append(flow_path)

    return code_snippets


def print_code_flows(code_snippets):
    all_code = []
    """优化后的结果显示函数"""
    for flow_idx, flow in enumerate(code_snippets, 1):
        print(f"\n🔗 代码流路径 {flow_idx}")
        for step_idx, step in enumerate(flow, 1):
            print(f"📂 文件: {step['file']}")
            print(f"📌 行号: {step['start_line']}-{step['end_line']}")
            print("🖥️ 代码片段:")
            print(f"```python\n{step['code']}\n```")
            all_code.append(step['code'])
            if step_idx < len(flow):
                print("=" * 30)
    all_code = '\n'.join(all_code)
    print("=" * 30)
    print(all_code)


if __name__ == "__main__":
    # 配置参数
    SARIF_FILE = r"C:\Users\59483\AppData\Roaming\Code\User\globalStorage\github.vscode-codeql\queries\SqlInjection.ql-sBbnTpoue1YOt1VkB_GP8\interpretedResults.sarif"
    SOURCE_ROOT = ""  # 替换为源代码根目录

    # 执行提取和显示
    extracted_flows = extract_code_from_sarif(SARIF_FILE, SOURCE_ROOT)
    print(f"\n✅ 发现 {len(extracted_flows)} 条唯一代码路径")
    print_code_flows(extracted_flows)