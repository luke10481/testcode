import requests

url = 'https://cloud.luchentech.com/api/maas/chat/completions'

headers = {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer 088b7aa5-bedb-4468-876a-fdc0fd107e19'
}
payload = {
    "model": "deepseek_r1",
    "messages": [
      {
        "role": "user",
        "content": "在mysql条件下，sql注入设置黑名单校验不全，被只有一种poc绕过的python代码的例子"
      }
    ],
    "stream": False,
    "max_tokens": 64 * 1024
}

response = requests.request("POST", url, json=payload, headers=headers)

print(response.json())