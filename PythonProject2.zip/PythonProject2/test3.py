import json


def extract_indented_code(sarif_path, source_root=''):
    """
    提取并保留代码缩进结构的增强版本
    """
    with open(sarif_path, 'r', encoding='utf-8') as f:
        sarif_data = json.load(f)

    code_flows = []
    file_cache = {}

    for run in sarif_data.get('runs', []):
        for result in run.get('results', []):
            for code_flow in result.get('codeFlows', []):
                for thread_flow in code_flow.get('threadFlows', []):
                    unique_steps = set()
                    flow_steps = []

                    for location in thread_flow.get('locations', []):
                        phys_loc = location.get('location', {}).get('physicalLocation', {})
                        if not phys_loc:
                            continue

                        # 解析文件位置
                        artifact_loc = phys_loc.get('artifactLocation', {})
                        uri = artifact_loc.get('uri')
                        if not uri:
                            continue

                        file_path = source_root + uri
                        region = phys_loc.get('region', {})
                        start_line = region.get('startLine')

                        if not start_line:
                            continue

                        # 生成唯一标识（文件+起始行）
                        step_id = f"{file_path}:{start_line}"
                        if step_id in unique_steps:
                            continue
                        unique_steps.add(step_id)

                        # 缓存文件内容
                        if file_path not in file_cache:
                            try:
                                with open(file_path, 'r', encoding='utf-8') as f:
                                    file_cache[file_path] = f.readlines()
                            except Exception as e:
                                print(f"文件读取失败: {file_path} - {str(e)}")
                                continue

                        # 提取完整代码行（保留缩进）
                        code_line = file_cache[file_path][start_line - 1].rstrip('\n')

                        # 自动检测缩进
                        indent = ''.join(c for c in code_line if c in (' ', '\t'))
                        indent_type = '制表符' if '\t' in indent else '空格'
                        indent_count = len(indent.replace('\t', '    '))  # 将制表符转换为4空格计算

                        flow_steps.append({
                            'file': file_path,
                            'line': start_line,
                            'code': code_line,
                            'indent': {
                                'type': indent_type,
                                'count': indent_count,
                                'raw': indent
                            }
                        })

                    if flow_steps:
                        code_flows.append(flow_steps)

    return code_flows


def display_code_hierarchy(code_flows):
    """带缩进层级的可视化输出"""
    for flow_idx, flow in enumerate(code_flows, 1):
        print(f"\n🔍 代码路径 {flow_idx}")
        prev_indent = 0

        for step in flow:
            # 计算缩进层级
            current_indent = step['indent']['count']
            indent_diff = current_indent - prev_indent

            # 生成缩进标记
            indent_symbol = '⇥' if step['indent']['type'] == '制表符' else '·'
            indent_visual = indent_symbol * step['indent']['count']

            print(f"📄 {step['file']}:{step['line']}")
            print(f"  缩进类型: {step['indent']['type']}({step['indent']['count']})")
            print(f"  {indent_visual}{step['code'].lstrip()}")
            print("━" * 50)
            prev_indent = current_indent


if __name__ == "__main__":
    # 配置参数
    SARIF_FILE = r"C:\Users\59483\AppData\Roaming\Code\User\globalStorage\github.vscode-codeql\queries\SqlInjection.ql-O5KbRWGb6su_V03yoSM5M\interpretedResults.sarif"
    SOURCE_ROOT = ""

    # 执行提取和显示
    code_data = extract_indented_code(SARIF_FILE, SOURCE_ROOT)
    display_code_hierarchy(code_data)