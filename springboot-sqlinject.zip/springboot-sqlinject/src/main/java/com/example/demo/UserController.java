package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/login")
    public List<User> login(@RequestParam String username, @RequestParam String password) {
        return userRepository.findByUsernameAndPassword(username, password);
    }
}
